Space Game BGM #1

It is a game sound with a theme of Space.

Two versions are included.

Full ver & Loop Ver.

It is free. It is freely usable.

Do not resell.

--------Contents-----

SpaceGameBgm#1_Galaxy Blues - Full Ver/ Mp3/ BPM 120/ 02:25

SpaceGameBgm#1_Galaxy Blues_Loop - Loop Ver/ Mp3/ BPM 120/ 01:23


If you have any problems with the product, please contact us by e-mail.

4crain@gmail.com