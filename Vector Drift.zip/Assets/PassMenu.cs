using UnityEngine;
using UnityEngine.SceneManagement;

public class PassMenu : MonoBehaviour
{
    public GameObject pausePanel, bg;

    public GameObject healthBar,timer;

    public GameObject volumePanel;

    private bool isPause = false;

     void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isPause)
            {
                ResumeGame();
                volumePanel.SetActive(false);
            }
            else
            {
                PauseGame();
            }
        }
    }

    public void PauseGame()
    {
        Time.timeScale = 0f;
        pausePanel.SetActive(true);
        bg.SetActive(true);
        isPause = true;
        healthBar.SetActive(false);
        timer.SetActive(false);
    }

    public void Volume()
    {
        pausePanel.SetActive(false);
        volumePanel.SetActive(true);
    }

    public void VolumeBack()
    {
        volumePanel.SetActive(false);
        pausePanel.SetActive(true);
    }

    public void ResumeGame()
    {
        Time.timeScale = 1f;
        pausePanel.SetActive(false);
        bg.SetActive(false);
        isPause = false;
        healthBar.SetActive(true);
        timer.SetActive(true);
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        Time.timeScale = 1f;
    }

    public void MainMenu()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 1);
    }

}
