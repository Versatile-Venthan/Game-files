using UnityEngine;

public class MoveLeft : MonoBehaviour
{
    private float speed = 5;
    private Rigidbody2D wallRb;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        wallRb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.left * Time.deltaTime * speed);
        if (wallRb.transform.position.x < -12)
        {
            Destroy(gameObject);
        }
    }
}
