using System.Collections;
using UnityEngine;

public class WallManager : MonoBehaviour
{
    public GameObject[] wall;     // Array to hold wall prefabs
    public GameObject[] electric; // Array to hold electric prefabs

    private bool spawnWalls = true; // Toggle to control which object type spawns

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(SwitchSpawning());
    }

    // Coroutine to switch spawning every 20 seconds
    IEnumerator SwitchSpawning()
    {
        while (true)
        {
            if (spawnWalls)
            {
                CancelInvoke(); // Stop any ongoing spawning
                InvokeRepeating("SpawnRandomWall", 1, 1.4f);
            }
            else
            {
                CancelInvoke(); // Stop any ongoing spawning
                InvokeRepeating("SpawnRandomElectric", 1, 1.4f);
            }

            spawnWalls = !spawnWalls; // Toggle the spawn flag
            yield return new WaitForSeconds(20); // Wait for 20 seconds before switching
        }
    }

    private void SpawnRandomWall()
    {
        int randomIndex = Random.Range(0, wall.Length);
        Vector2 spawnPos = new Vector2( 14f, 0); // Adjust y-position for variety
        Instantiate(wall[randomIndex], spawnPos, wall[randomIndex].gameObject.transform.rotation);
    }

    private void SpawnRandomElectric()
    {
        int randomIndex = Random.Range(0, electric.Length);
        Vector2 spawnPos = new Vector2( 14f, 0); // Adjust y-position for variety
        Instantiate(electric[randomIndex], spawnPos, electric[randomIndex].gameObject.transform.rotation);
    }
}
