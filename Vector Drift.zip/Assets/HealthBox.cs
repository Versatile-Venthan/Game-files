using UnityEngine;

public class HealthBox : MonoBehaviour
{
    public GameObject healthBox;
    void Start()
    {
        float healthSpawn = Random.Range(10, 20);
        InvokeRepeating("SpawnHealthBox", 5, healthSpawn);
    }

    private void SpawnHealthBox()
    {
        float ySpawn = Random.Range(2.5f, -3);
        Vector2 healthBoxSpawn = new Vector2(10, ySpawn);
        Instantiate(healthBox, healthBoxSpawn, gameObject.transform.rotation);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
