using UnityEngine;
using UnityEngine.UIElements;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    public int maxHealth = 100;
    public int currentHealth;
    public HealthBar healthBar;

    public GameObject trail;
    private Rigidbody2D playerRb;
    public float speed = 5f;

    AudioManager audioManager;
    private float minX, maxX, minY, maxY;

    private void Awake()
    {
        audioManager = GameObject.FindGameObjectWithTag("Audio").GetComponent<AudioManager>();
    }

    private void Start()
    {
        playerRb = GetComponent<Rigidbody2D>();

        currentHealth = maxHealth;
        healthBar.SetMaxHealth(maxHealth);

        InvokeRepeating("SpawnTrail", 1, .05f);

        Vector2 screenBottomLeft = Camera.main.ScreenToWorldPoint(new Vector2(0, 0));
        Vector2 screenTopRight = Camera.main.ScreenToWorldPoint(new Vector2(1920, 1080));

        minX = screenBottomLeft.x; 
        maxX = screenTopRight.x;   
        minY = screenBottomLeft.y; 
        maxY = screenTopRight.y;
    }

    private void SpawnTrail()
    {
        Instantiate(trail, transform.position, trail.gameObject.transform.rotation);
    }

    void Update()
    {
        float verticalInput = Input.GetAxis("Vertical");
        float horizontalInput = Input.GetAxis("Horizontal");

        transform.Translate(Vector3.up *verticalInput * Time.deltaTime * speed);
        transform.Translate(Vector3.right * horizontalInput * Time.deltaTime * speed);

        float clampedX = Mathf.Clamp(transform.position.x, minX, maxX);
        float clampedY = Mathf.Clamp(transform.position.y, minY, maxY);
        transform.position = new Vector3(clampedX, clampedY, transform.position.z);

       
        if (transform.position.x <= minX)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }

        if (currentHealth <= 0)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
        if (currentHealth >= 100)
        {
            currentHealth = 100;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("EffectorArea"))
        {
            playerRb.linearVelocity = Vector2.zero; 
        }

        if (other.gameObject.CompareTag("Eletric"))
        {
            audioManager.PlaySFX(audioManager.eletric);
            TakeDamage(30);
        }

        if (other.gameObject.CompareTag("Eletric1"))
        {

        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Wall"))
        {
            audioManager.PlaySFX(audioManager.wall);
            Destroy(other.gameObject);
            TakeDamage(20);
        }

        if (other.gameObject.CompareTag("Health"))
        {
            Destroy(other.gameObject);
            IncreaseHealth(40);
            audioManager.PlaySFX(audioManager.health);
        }

        

    }

    void TakeDamage(int damage)
    {
        currentHealth -= damage;

        healthBar.SetHealth(currentHealth);
    }

    void IncreaseHealth(int health)
    {
        currentHealth += health;

        healthBar.SetHealth(currentHealth);
    }

}
